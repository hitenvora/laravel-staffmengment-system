<?php
/**
 * The left sidebar template
 *
 *
 * @package Customizr
 * @since Customizr 3.1.0
 */
czr_fn_render_template(
  'content/sidebars/left_sidebar',
   array( 'model_class' => 'content/sidebars/sidebar' )
);
