<?php
/**
* The template for displaying the author info small
*
*/
?>
<div class="author-info" <?php czr_fn_echo('element_attributes') ?>>
  <?php czr_fn_echo( 'author_with_avatar', 'post_metas' ); ?>
</div>